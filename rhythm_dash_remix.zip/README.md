# Rhythm Dash: Ultimate Remix

A rhythm-based game built in React with full beat-sync, power-ups, and stylish themes.
