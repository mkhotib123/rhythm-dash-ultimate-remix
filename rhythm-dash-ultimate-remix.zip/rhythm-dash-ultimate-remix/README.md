# Rhythm Dash: Ultimate Remix

## Launch Instructions

1. `cd server` → `npm install` → `npm start`
2. `cd client` → `npm install` → `npm run dev`
3. PostgreSQL: run schema.sql

