# Rhythm Dash Remix

A multiplayer + solo rhythm game experience. Tap into the beat. Conquer your rhythm. Challenge the world.

## Features

- Multiplayer and Solo Modes
- Animated transitions
- Thematic backgrounds and soundtracks
- Auto-deploy ready for Vercel, Netlify, or Render
